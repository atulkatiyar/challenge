package com.spring.cloud.client.controller.changeloglevel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RefreshScope
public class LogLevelController1 {

    private static final Logger logger = LoggerFactory.getLogger(LogLevelController1.class);

    /**
     * Endpoint to perform an action and log messages at different levels.
     */
    @GetMapping("/performAction1")
    public void performAction() {
        logger.debug("[LogLevelController] Debug message from LogExample");
        logger.info("[LogLevelController] Info message from LogExample");
        logger.warn("[LogLevelController]  Warning message from LogExample");
        logger.error("[LogLevelController]  Error message from LogExample");
    }
}
