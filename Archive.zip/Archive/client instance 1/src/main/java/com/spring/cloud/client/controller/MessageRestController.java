package com.spring.cloud.client.controller;

import com.spring.cloud.client.controller.changeloglevel.LogLevelController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class MessageRestController {

    private static final Logger logger = LoggerFactory.getLogger(MessageRestController.class);
    @Value("${message:Hello default}")
    private String message;



    @RequestMapping("/message")
    String getMessage() {
        logger.debug("[MessageRestController] Debug message from LogExample");
        logger.info("[MessageRestController] Info message from LogExample");
        logger.warn("[MessageRestController]  Warning message from LogExample");
        logger.error("[MessageRestController]  Error message from LogExample");
        return this.message;
    }
}
