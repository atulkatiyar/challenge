package com.lseg.ipps.solutions.tpl.record;

public record Template(Long id, String content) {}
