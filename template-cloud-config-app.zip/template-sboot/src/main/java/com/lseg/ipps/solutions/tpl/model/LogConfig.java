package com.lseg.ipps.solutions.tpl.model;

import java.io.Serializable;

public class LogConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    private String loggerName;

    private String loggerLevel;

    public LogConfig() {}

    public LogConfig(String loggerName, String loggerLevel) {
        this.loggerName = loggerName;
        this.loggerLevel = loggerLevel;
    }

    public String getLoggerName() {
        return loggerName;
    }

    public void setLoggerName(String loggerName) {
        this.loggerName = loggerName;
    }

    public String getLoggerLevel() {
        return loggerLevel;
    }

    public void setLoggerLevel(String loggerLevel) {
        this.loggerLevel = loggerLevel;
    }
}
