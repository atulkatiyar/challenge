package com.lseg.ipps.solutions.tpl.service;

import com.lseg.ipps.solutions.tpl.model.LogConfig;
import java.util.Map;
import java.util.Set;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.config.Configurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LogConfigService {

    @Autowired private CacheService cacheService;

    public Set<Map.Entry<String, String>> findAll() {
        return cacheService.findAll();
    }

    public void clearCache() {
        cacheService.deleteAll();
    }

    public void update(LogConfig logConfig) {
        Level level =
                Level.toLevel(logConfig.getLoggerName(), Level.getLevel(logConfig.getLoggerLevel()));
        if ("ROOT".equalsIgnoreCase(logConfig.getLoggerName())) {
            Configurator.setRootLevel(level);
        } else {
            Logger logger = (Logger) LogManager.getLogger(logConfig.getLoggerName());
            Configurator.setLevel(logger.getName(), level);
        }
    }
}
