package com.lseg.ipps.solutions.tpl.service;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;

@Service
public class CacheService {

    private final IMap<String, String> cacheMap;

    public CacheService(HazelcastInstance hazelcastInstance) {
        this.cacheMap = hazelcastInstance.getMap("centralizedCache");
    }

    public Set<Map.Entry<String, String>> findAll() {
        return cacheMap.entrySet();
    }

    public void put(String key, String value) {
        cacheMap.put(key, value);
    }

    public void get(String key) {
        cacheMap.get(key);
    }

    public void delete(String key) {
        cacheMap.delete(key);
    }

    public void deleteAll() {
        cacheMap.clear();
    }
}
