package com.lseg.ipps.solutions.tpl.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pc/v1/naming") // version you API.
public class RestApiNamingController {

    // Use hyphens to improve readability of URI.
    @GetMapping("/template-events")
    public String getTemplateEvents() {
        return "Use hyphens to improve readability of URI.";
    }

    // Use nouns to represent resources, not verbs.
    @GetMapping("/template-events/{templateEventId}")
    public String getTemplateEventById(@PathVariable("templateEventId") Long templateEventId) {
        return "Use nouns to represent resources, not verbs. Template event id is: " + templateEventId;
    }

    // Use pluralized nouns for resources.
    @GetMapping("/template-prices")
    public String getTemplatePrices() {
        return "Use plural nouns for resources.";
    }

    // Use query components to filter URI collections.
    // To test it , run the application and try it out on
    // <localhost>:<port>/api/pc/v1/naming/prices?currency-code=GBP
    @GetMapping("/template-prices/{currency-code}")
    public String getTemplatePricesBy(@PathVariable("currency-code") String currencyCode) {
        return "Use query components to filter URI collections. Currency code is: " + currencyCode;
    }

    // Use forward slashes for hierarchy only but not trailing forward slash.
    @GetMapping("/use/forward/slashes/for/hierarchy/only")
    public String useForwardSlashesForHierarchy() {
        return "Do not use trailing forward slash";
    }

    // Use RestAPI methods properly

    // Use GET method to retrieve a resource
    @GetMapping("/template/{templateId}")
    public String getTemplateById(@PathVariable("templateId") Long templateId) {
        return "Retrieved template resource with id: " + templateId;
    }

    // Use POST method to create a resource
    @PostMapping("/template")
    public String createTemplate() {
        return "Created new template resource.";
    }

    // Use PUT method to update a resource
    @PutMapping("/template/{templateId}")
    public String updateTemplateById(@PathVariable("templateId") Long templateId) {
        return "Updated template resource with id: " + templateId;
    }

    // Use DELETE method to delete a resource
    @DeleteMapping("/template/{templateId}")
    public String deleteTemplateById(@PathVariable("templateId") Long templateId) {
        return "Deleted template resource with id: " + templateId;
    }
}
