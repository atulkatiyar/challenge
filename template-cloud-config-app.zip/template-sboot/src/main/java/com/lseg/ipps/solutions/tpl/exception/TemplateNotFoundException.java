package com.lseg.ipps.solutions.tpl.exception;

public class TemplateNotFoundException extends RuntimeException {
    public TemplateNotFoundException(Long templateId) {
        super("Template not found with ID: " + templateId);
    }
}
