package com.lseg.ipps.solutions.tpl.controller;

import com.lseg.ipps.solutions.tpl.record.Template;
import com.lseg.ipps.solutions.tpl.service.TemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/pc/v1/template")
public class TemplateController {

    @Autowired private TemplateService templateService;

    @GetMapping("/not-found/{templateId}")
    public ResponseEntity<Template> getTemplateNotFound(@PathVariable("templateId") Long templateId) {
        Template template = templateService.getTemplateByIdNotFound(templateId);
        return ResponseEntity.ok(template);
    }

    @GetMapping("/{templateId}")
    public ResponseEntity<Template> getTemplate(@PathVariable("templateId") Long templateId) {
        Template template = templateService.getTemplateById(templateId);
        return ResponseEntity.ok(template);
    }

    @GetMapping("/exception")
    public ResponseEntity<Template> getTemplateWillThrowException() throws Exception {
        Template template = templateService.willThrowUnexpectedException();
        return ResponseEntity.ok(template);
    }
}
