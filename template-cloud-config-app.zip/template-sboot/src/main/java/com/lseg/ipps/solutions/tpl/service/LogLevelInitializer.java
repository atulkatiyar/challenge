package com.lseg.ipps.solutions.tpl.service;

import com.lseg.ipps.solutions.tpl.model.LogConfig;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class LogLevelInitializer {

    @Autowired private LogConfigService logConfigService;

    @EventListener(ApplicationReadyEvent.class)
    public void setInitialLogLevels() {
        // logConfigService.clearCache();
        Set<Map.Entry<String, String>> configs = logConfigService.findAll();
        Optional.of(configs)
                .ifPresent(
                        configs1 ->
                                configs1.forEach(
                                        config -> {
                                            if ((config.getKey() != null && !config.getKey().isEmpty())
                                                    && (config.getValue() != null && !config.getValue().isEmpty())) {
                                                LogConfig logConfig = new LogConfig(config.getKey(), config.getValue());
                                                logConfigService.update(logConfig);
                                            }
                                        }));
    }
}
