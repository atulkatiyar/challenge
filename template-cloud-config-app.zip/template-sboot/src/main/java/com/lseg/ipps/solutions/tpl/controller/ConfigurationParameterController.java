package com.lseg.ipps.solutions.tpl.controller;

import com.lseg.ipps.solutions.tpl.request.ConfigurationParameterRequest;
import com.lseg.ipps.solutions.tpl.service.ConfigurationService;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pc/v1/configuration")
public class ConfigurationParameterController {

    @Autowired ConfigurationService configurationService;

    // To test it , run the application and try it out on
    // <localhost>:<port>/api/pc/v1/configuration/parameters?paramKey=""

    /**
     * API to retrieve parameter value by passing key
     *
     * @param paramKey
     * @return
     */
    @GetMapping("/parameters/{paramKey}")
    public String getParameterValueByKey(@PathVariable("paramKey") String paramKey) {
        return configurationService.getParameterValueByKey(paramKey);
    }

    /**
     * API to retrieve the parameters by passing the path
     *
     * @param configurationParameterRequest @{@link ConfigurationParameterRequest}
     * @return @{@link Map}
     */
    @PostMapping("/parameters")
    public Map<String, String> getParameterValuesByPath(
            @RequestBody ConfigurationParameterRequest configurationParameterRequest) {
        return configurationService.getParameters(configurationParameterRequest);
    }
}
