package com.lseg.ipps.solutions.tpl.interceptor;

import jakarta.annotation.Nonnull;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class TraceIdInterceptor implements HandlerInterceptor {

    private static final String TRACE_ID_HEADER = "X-Trace-Id";
    private static final String MDC_TRACE_ID_KEY = "traceId";
    private final Logger log = LoggerFactory.getLogger(TraceIdInterceptor.class);

    // HandlerInterceptor.preHandle method signature specifies 'throws Exception'
    @SuppressWarnings("RedundantThrows")
    @Override
    public boolean preHandle(
            @Nonnull final HttpServletRequest request,
            @Nonnull final HttpServletResponse response,
            @Nonnull final Object handler)
            throws Exception {

        log.trace("Pre handle started");
        String traceId = request.getHeader(TRACE_ID_HEADER);

        if (traceId == null || traceId.isEmpty()) {
            log.info("X-Trace-ID header is empty");
            traceId = generateTraceId();
            log.trace("New traceId generated: {}", traceId);
        }

        log.trace("Using traceId: {}", traceId);
        request.setAttribute(TRACE_ID_HEADER, traceId);
        response.setHeader(TRACE_ID_HEADER, traceId);

        // Use Log4j's MDC (Mapped Diagnostic Context) feature to store the traceId, so it
        // is accessible to all log statements made during the execution of a particular thread.
        MDC.put(MDC_TRACE_ID_KEY, traceId);
        return true;
    }

    /**
     * Threads are reused to handle multiple requests, so remove must be called to prevent the
     * identifier leaking into log statements for subsequent requests
     */
    // HandlerInterceptor.afterCompletion method signature specifies 'throws Exception'
    @SuppressWarnings("RedundantThrows")
    @Override
    public void afterCompletion(
            @Nonnull HttpServletRequest request,
            @Nonnull HttpServletResponse response,
            @Nonnull Object handler,
            @Nullable Exception ex)
            throws Exception {
        log.trace("Removing traceId key from MDC.");
        MDC.remove(MDC_TRACE_ID_KEY);
    }

    private String generateTraceId() {
        return UUID.randomUUID().toString();
    }
}
