package com.lseg.ipps.solutions.tpl.service;

import com.lseg.ipps.solutions.tpl.exception.TemplateNotFoundException;
import com.lseg.ipps.solutions.tpl.record.Template;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class TemplateService {
    private final Logger log = LoggerFactory.getLogger(TemplateService.class);

    public Template getTemplateByIdNotFound(Long templateId) {
        Template template = getTemplateFromDatabaseNotFound(templateId);

        if (template == null) {
            log.info("Template by id {} id not found", templateId);

            throw new TemplateNotFoundException(templateId);
        }
        return template;
    }

    public Template getTemplateById(Long templateId) {
        log.trace("Retrieving template by id {}", templateId);
        Template template = getTemplateFromDatabase(templateId);

        if (template == null) {
            throw new TemplateNotFoundException(templateId);
        }
        log.trace("Returning template by id {}", templateId);
        return template;
    }

    private Template getTemplateFromDatabaseNotFound(Long templateId) {
        return null;
    }

    private Template getTemplateFromDatabase(Long templateId) {
        return new Template(templateId, "template content from database");
    }

    public Template willThrowUnexpectedException() throws Exception {
        int num = 1 / 0;
        return null;
    }
}
