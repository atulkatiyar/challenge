package com.lseg.ipps.solutions.tpl.service;

import com.lseg.ipps.solutions.tpl.request.ConfigurationParameterRequest;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ssm.SsmClient;
import software.amazon.lambda.powertools.parameters.ParamManager;
import software.amazon.lambda.powertools.parameters.SSMProvider;

@Service
public class ConfigurationService {

    private final Logger log = LoggerFactory.getLogger(ConfigurationService.class);

    @Value("${aws.ssm.parameter.cache.ttl}")
    private int maxAge;

    /**
     * Method to get configuration parameter value by key
     *
     * @param paramKey @{@link String}
     * @return @{@link String}
     */
    public String getParameterValueByKey(String paramKey) {

        SsmClient ssmClient =
                SsmClient.builder()
                        .region(Region.US_EAST_1)
                        .credentialsProvider(DefaultCredentialsProvider.create())
                        .build();

        SSMProvider ssmProvider = ParamManager.getSsmProvider(ssmClient);
        log.debug("DEBUG LOG:: paramKey " + paramKey);
        log.info("INFO LOG:: paramKey " + paramKey);
        log.trace("TRACE:: paramKey " + paramKey);
        return ssmProvider.withMaxAge(maxAge, ChronoUnit.SECONDS).get(paramKey);
    }

    /**
     * Method to get parameter values for connection String
     *
     * @param configurationParameterRequest @{@link ConfigurationParameterRequest}
     * @return @{@link Map}
     */
    public Map<String, String> getParameters(
            ConfigurationParameterRequest configurationParameterRequest) {

        SsmClient ssmClient =
                SsmClient.builder()
                        .region(Region.US_EAST_1)
                        .credentialsProvider(DefaultCredentialsProvider.create())
                        .build();

        SSMProvider ssmProvider = ParamManager.getSsmProvider(ssmClient);

        // Retrieve multiple parameters recursively from a path prefix
        Map<String, String> values =
                ssmProvider.recursive().getMultiple(configurationParameterRequest.getPath());

        return values;
    }
}
