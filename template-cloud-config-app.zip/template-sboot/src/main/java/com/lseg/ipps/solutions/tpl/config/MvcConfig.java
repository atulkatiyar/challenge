package com.lseg.ipps.solutions.tpl.config;

import com.lseg.ipps.solutions.tpl.interceptor.TraceIdInterceptor;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig implements WebMvcConfigurer {
    private final TraceIdInterceptor traceIdInterceptor;

    public MvcConfig(final TraceIdInterceptor traceIdInterceptor) {
        this.traceIdInterceptor = traceIdInterceptor;
    }

    @Bean
    public OpenAPI usersMicroserviceOpenAPI(BuildProperties buildProperties) {
        return new OpenAPI()
                .info(
                        new Info()
                                .title("Template App API Documentation")
                                .version(buildProperties.getVersion())
                                .description("Version built on: " + buildProperties.getTime()));
    }

    @Override
    public void addInterceptors(final InterceptorRegistry registry) {
        registry.addInterceptor(traceIdInterceptor);
    }
}
