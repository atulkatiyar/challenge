package com.lseg.ipps.solutions.tpl.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.lseg.ipps.solutions.tpl.exception.TemplateNotFoundException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
class TemplateControllerTest {

    private static final String ENDPOINT = "/api/pc/v1/template";
    private static final String ENDPOINT_NOT_FOUND = "/api/pc/v1/template/not-found";
    private static final String URI_PARAMETER_TEMPLATE_ID = "/123";
    private static final int EXPECTED_RESPONSE_ID = 123;
    private static final String EXPECTED_RESPONSE_CONTENT = "template content from database";
    private static final String EXPECTED_RESPONSE_CONTENT_NOT_FOUND =
            "Template not found with ID: 123";
    private static final String ENDPOINT_TEMPLATE_EXCEPTION = "/api/pc/v1/template/exception";
    private static final String EXPECTED_ENDPOINT_TEMPLATE_RESPONSE =
            "java.lang.ArithmeticException: / by zero";

    @Autowired MockMvc mockMvc;

    @Test
    void templateTestNotFound() throws Exception {
        MvcResult result =
                mockMvc
                        .perform(MockMvcRequestBuilders.get(ENDPOINT_NOT_FOUND + URI_PARAMETER_TEMPLATE_ID))
                        .andExpect(status().isNotFound())
                        .andDo(print())
                        .andReturn();

        assertInstanceOf(TemplateNotFoundException.class, result.getResolvedException());
        JSONObject jsonResponseBody = new JSONObject(result.getResponse().getContentAsString());
        assertEquals(EXPECTED_RESPONSE_CONTENT_NOT_FOUND, jsonResponseBody.get("message"));
    }

    @Test
    void templateTestWithMatchers() throws Exception {
        mockMvc
                .perform(MockMvcRequestBuilders.get(ENDPOINT + URI_PARAMETER_TEMPLATE_ID))
                .andExpect(status().is2xxSuccessful())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(EXPECTED_RESPONSE_ID))
                .andExpect(MockMvcResultMatchers.jsonPath("$.content").value(EXPECTED_RESPONSE_CONTENT))
                .andReturn();
    }

    @Test
    void templateTestUnhandledException() throws Exception {
        MvcResult result =
                mockMvc
                        .perform(MockMvcRequestBuilders.get(ENDPOINT_TEMPLATE_EXCEPTION))
                        .andExpect(status().isInternalServerError())
                        .andReturn();

        JSONObject jsonResponseBody = new JSONObject(result.getResponse().getContentAsString());
        assertEquals(EXPECTED_ENDPOINT_TEMPLATE_RESPONSE, jsonResponseBody.get("message"));
    }
}
