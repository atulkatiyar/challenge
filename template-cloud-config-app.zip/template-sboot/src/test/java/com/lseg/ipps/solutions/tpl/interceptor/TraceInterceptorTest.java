package com.lseg.ipps.solutions.tpl.interceptor;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

@ExtendWith(MockitoExtension.class)
class TraceIdInterceptorTest {

    private TraceIdInterceptor interceptor;

    @Mock private HttpServletRequest request;

    @Mock private HttpServletResponse response;

    @Mock private Object handler;

    private static final String TRACE_ID_HEADER = "X-Trace-Id";
    private static final String MDC_TRACE_ID_KEY = "traceId";

    @BeforeEach
    public void setup() {
        interceptor = new TraceIdInterceptor();
    }

    @AfterEach
    public void tearDown() {
        verifyNoMoreInteractions(request, response, handler);
    }

    @Test
    void preHandleWithExistingTraceId() throws Exception {
        final String traceId = "ABC123";
        when(request.getHeader(TRACE_ID_HEADER)).thenReturn(traceId);

        assertNull(MDC.get(MDC_TRACE_ID_KEY));

        assertTrue(interceptor.preHandle(request, response, handler));

        assertEquals(traceId, MDC.get(MDC_TRACE_ID_KEY));

        verify(request).setAttribute(TRACE_ID_HEADER, traceId);
        verify(response).setHeader(TRACE_ID_HEADER, traceId);

        interceptor.afterCompletion(request, response, handler, null);
        assertNull(MDC.get(MDC_TRACE_ID_KEY));
    }

    @Test
    void preHandleWithNullTraceId() throws Exception {
        preHandleWithoutExistingTraceId(null);
    }

    @Test
    void preHandleWithEmptyTraceId() throws Exception {
        preHandleWithoutExistingTraceId("");
    }

    private void preHandleWithoutExistingTraceId(final String traceId) throws Exception {
        when(request.getHeader(TRACE_ID_HEADER)).thenReturn(traceId);

        assertNull(MDC.get(MDC_TRACE_ID_KEY));

        assertTrue(interceptor.preHandle(request, response, handler));

        assertThat(MDC.get(MDC_TRACE_ID_KEY)).hasSize(36);

        verify(request)
                .setAttribute(eq(TRACE_ID_HEADER), argThat(argument -> ((String) argument).length() == 36));
        verify(response).setHeader(eq(TRACE_ID_HEADER), argThat(argument -> argument.length() == 36));

        interceptor.afterCompletion(request, response, handler, null);
        assertNull(MDC.get(MDC_TRACE_ID_KEY));
    }
}
