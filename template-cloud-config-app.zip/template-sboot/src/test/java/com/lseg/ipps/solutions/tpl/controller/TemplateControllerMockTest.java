package com.lseg.ipps.solutions.tpl.controller;

import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.lseg.ipps.solutions.tpl.record.Template;
import com.lseg.ipps.solutions.tpl.service.TemplateService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureMockMvc
public class TemplateControllerMockTest {

    private static final String ENDPOINT = "/api/pc/v1/template";
    private static final String URI_PARAMETER_TEMPLATE_ID = "/123";
    private static final String MOCKED_CONTENT = "this is mocked content";

    @Autowired private MockMvc mockMvc;

    @MockBean private TemplateService templateService;

    @Test
    public void templateServiceShouldReturnNewMockedTemplate() throws Exception {

        when(templateService.getTemplateById(any())).thenReturn(new Template(321L, MOCKED_CONTENT));

        mockMvc
                .perform(MockMvcRequestBuilders.get(ENDPOINT + URI_PARAMETER_TEMPLATE_ID))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string(containsString(MOCKED_CONTENT)));
    }
}
