package com.lseg.ipps.solutions.tpl.agent;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.instrument.Instrumentation;
import java.net.HttpURLConnection;
import java.net.URL;

public class LogLevelStartupAgent {

    private static final String LOG4J_XML_URL = "http://localhost:8086/generate-log4j-xml";
    private static final String LOG4J_XML_PATH = "/Users/komalsharma/Downloads/template-logLevel-sboot/target/classes/log4j2.xml";

    public static void premain(String agentArgs, Instrumentation inst) {
        try {
            String response = callRestService();
            System.out.println("REST API Response: " + response);
        } catch (Exception e) {
            System.err.println("Error calling REST API: " + e.getMessage());
        }
    }

    private static String callRestService() {
        try {
            URL url = new URL(LOG4J_XML_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("Accept", "application/xml");
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000); // Timeout settings
            connection.setReadTimeout(10000);
            int responseCode = connection.getResponseCode();
            if (responseCode == 200) {
                File outputFile = new File(LOG4J_XML_PATH);
                // Read the response and write it to the file
                try (InputStream inputStream = connection.getInputStream();
                     FileOutputStream fileOutputStream = new FileOutputStream(outputFile)) {

                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        fileOutputStream.write(buffer, 0, bytesRead);
                    }
                }
                return "success";
            } else {
                return "";
            }
        } catch (Exception e) {
            System.err.println("Error calling REST API: " + e.getMessage());
        }
        return "";
    }
}
