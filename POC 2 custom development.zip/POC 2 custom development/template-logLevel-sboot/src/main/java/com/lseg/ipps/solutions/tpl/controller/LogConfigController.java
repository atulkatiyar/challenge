package com.lseg.ipps.solutions.tpl.controller;

import com.lseg.ipps.solutions.tpl.service.LogLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping
public class LogConfigController {
    @Autowired
    private LogLevelService logLevelService;

    @GetMapping("/checkLogLevel")
    public void showDashboard() {
         logLevelService.testLoggingLevel();
    }

}

