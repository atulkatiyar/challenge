package com.lseg.ipps.solutions.tpl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LogLevelChangeCallbackService {

    @Autowired private CacheService cacheService;

    public void onLogLevelChanged(String loggerName, String loggingLevel) {
        try {
            cacheService.put(loggerName, loggingLevel);
        } catch (Exception e) {
            System.out.println(e.getStackTrace());
        }
    }
}
