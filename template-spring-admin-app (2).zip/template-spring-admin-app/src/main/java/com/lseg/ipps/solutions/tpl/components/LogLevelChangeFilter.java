package com.lseg.ipps.solutions.tpl.components;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.ipps.solutions.tpl.custom.servlet.CustomHttpServletRequestWrapper2;
import com.lseg.ipps.solutions.tpl.service.InstanceService;
import com.lseg.ipps.solutions.tpl.service.LogLevelChangeCallbackService;
import de.codecentric.boot.admin.server.domain.entities.Instance;
import de.codecentric.boot.admin.server.domain.values.Endpoint;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class LogLevelChangeFilter  implements Filter {

    @Autowired private LogLevelChangeCallbackService logLevelChangeCallbackService;

    @Autowired
    private InstanceService instanceService;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(
            ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        String uri = httpServletRequest.getRequestURI();
        String method = httpServletRequest.getMethod();

        if ("POST".equalsIgnoreCase(method) && uri.contains("/actuator/loggers/")) {


            // String loggingLevelFromPayLoad = "WARN";//parsePayLoad(httpServletRequest);
            // CustomHttpServletRequestWrapper customHttpServletRequestWrapper = new
            // CustomHttpServletRequestWrapper(httpServletRequest);
            filterChain.doFilter(servletRequest, servletResponse);

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            String[] appUrl = uri.split("/");
            String appName;
            if (appUrl.length > 2) {
                appName = appUrl[2];
            } else {
                appName = "";
            }
            String loggerUrl = null;
            List<Instance> registeredApps = instanceService.getAllRegisteredInstances().collectList()
                    .block();
            Optional<Instance> registeredApp = Optional.empty();
            if(registeredApps != null) {
                registeredApp = registeredApps.stream()
                        .filter(instance -> instance.isRegistered()
                                && instance.getRegistration().getName().equalsIgnoreCase(appName))
                        .toList().stream().findFirst();
            }

            if(registeredApp.isPresent()) {
                RestTemplate restTemplate = new RestTemplate();
                Optional<Endpoint> url = registeredApp.get().getEndpoints().get("loggers");
                if (!url.isEmpty()) {
                    Map<String, Object> response = restTemplate.getForObject(url.get().getUrl(), Map.class);
                    System.out.println("");
                }
            }

                    /*.subscribe(instance -> {
                        String instanceId = instance.getId().getValue();
                        String status = instance.getStatusInfo().getStatus();  // e.g., "UP" or "DOWN"
                        String url = instance.getRegistration().getServiceUrl();
                        //loggerUrl = instance.getEndpoints().get("loggers");
                        System.out.printf("Instance ID: %s, Status: %s, URL: %s%n", instanceId, status, url);
                    });*/

            String loggingLevelFromPayLoad = "";
            loggingLevelFromPayLoad = "WARN";
            String[] splitUrl = uri.substring(uri.indexOf("/actuator/loggers/")).split("/");
            if (splitUrl.length > 0) {
                String loggerName = splitUrl[3];
                if ((loggerName != null && !loggerName.isEmpty())
                        && (loggingLevelFromPayLoad != null && !loggingLevelFromPayLoad.isEmpty())) {
                    logLevelChangeCallbackService.onLogLevelChanged(loggerName, loggingLevelFromPayLoad);
                }
            }


        } else {
            filterChain.doFilter(servletRequest, servletResponse);
        }
    }

    private static String parsePayLoad(HttpServletRequest httpServletRequest) throws IOException {
        JsonNode value = null;
        CustomHttpServletRequestWrapper2 customRequest =
                new CustomHttpServletRequestWrapper2(httpServletRequest);
        String payLoad = customRequest.getRequestBodyAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.readTree(payLoad);
        Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            value = field.getValue();
        }
        return value != null ? value.asText() : "";
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}
