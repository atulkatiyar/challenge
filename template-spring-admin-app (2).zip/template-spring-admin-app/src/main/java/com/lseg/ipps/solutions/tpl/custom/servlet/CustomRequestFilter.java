package com.lseg.ipps.solutions.tpl.custom.servlet;


import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class CustomRequestFilter /*implements Filter*/ {

    /*@Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String uri = httpServletRequest.getRequestURI();
        String method = httpServletRequest.getMethod();

        if ("POST".equalsIgnoreCase(method) && uri.contains("/actuator/loggers/")) {
            // Wrap the request to read and modify the request body
            CustomHttpServletRequestWrapper requestWrapper = new CustomHttpServletRequestWrapper((HttpServletRequest) request);
            String payload = new String(requestWrapper.getInputStream().readAllBytes());
            chain.doFilter(request, response);
        } else{
            chain.doFilter(request, response);
        }

    }

    private String modifyBody(String body) {
        // Example modification: Replace "oldValue" with "newValue" in the request body
        return body.replace("oldValue", "newValue");
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}*/
}

